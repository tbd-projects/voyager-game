//
// Created by volodya on 09.05.2021.
//

#include "game_manager/game_manager.h"

namespace game_manager {


    GameManager::GameManager(::graphics::ICanvas &canvas, ::event_controller::IEventable &eventable)
    : /*_game(_controller.get()),*/ _canvas(canvas)
    {

    }

    void GameManager::start_game() {

    }

    void GameManager::pause_game() {

    }

    void GameManager::end_game() {

    }

    void GameManager::open_main_menu() {

    }

    void GameManager::open_levels_menu() {

    }

}